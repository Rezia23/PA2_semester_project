
#include "CApplicationConsole.h"

using namespace std;

int main() {

    CApplicationConsole app;
    app.PrintInstructions();
    app.Run();
    return 0;
}
