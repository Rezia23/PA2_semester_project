//
// Created by hrubate1 on 05.05.2020.
//

#include "CBinaryOperator.h"
