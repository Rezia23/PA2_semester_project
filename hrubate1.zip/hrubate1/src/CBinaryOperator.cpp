//
// Created by terez on 05.05.2020.
//

#include "CBinaryOperator.h"
